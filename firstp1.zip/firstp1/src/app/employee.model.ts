export interface Employee {
    Id: any;
    EmployeeName:string
    department: String;
    StarTimeUtc:string;
    EndTimeUtc:string;
    EntryNotes:String;
    DeletedOn:String;
    Total:string
  }